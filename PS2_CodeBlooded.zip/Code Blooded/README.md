note to the judges

model is working with 49.35 % accuracy
faced errors in linking of the model and frontend hence couldn't complete

thank you